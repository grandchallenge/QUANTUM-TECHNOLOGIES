from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
assert m['record_type']=='QTR_PAPER_A_DRAFT_REVIEW_BUNDLE/1'
expected={x['path'] for x in m['files']} | {'MANIFEST.json','README_REVIEW.md','verify_bundle.py'}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
generated={'publication/figures/paper_a_c18_compiled_nodes.svg',
           'publication/figures/paper_a_c72_elimination_width.svg',
           'publication/figures/paper_a_selector_pipeline.svg'}
assert expected <= actual and (actual-expected) <= generated, (
    'file list drift',sorted(expected-actual),sorted((actual-expected)-generated))
for row in m['files']:
 p=root/row['path']
 b=p.read_bytes()
 assert len(b)==row['bytes'],row['path']
 assert hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
print('QTR_PAPER_A_DRAFT_REVIEW_BUNDLE_HASHES_PASS',len(m['files']))
