# QTR PAPER A — DRAFT REVIEW BUNDLE

Status: working manuscript draft; NOT published, certified or submitted.
Source: protected grandchallenge/QUANTUM-TECHNOLOGIES main
Commit: cd2b16d3d1fa5974b5eee61dfdb51c6a5f9d8868
UTC date: 2026-11-19

Contents: 18-page PDF draft; manuscript Markdown; candidate reference theorem; 12-reference bibliography audit;
one C18 full-domain compiled semantics report; C72 symbolic/oracle and finite decoder reports;
data/evidence manifest; three reproducible figures; generator; tests;
source-locked C72 reference utilities. All paths and SHA-256 digests appear in MANIFEST.json.

To check byte integrity (Python 3.10+):
    python3 verify_bundle.py
To execute bounded 9/9 hostile and coordinate checks:
    python3 publication/tests/test_paper_a_math_obligations.py -v
    python3 publication/tests/test_paper_a_c72_coordinate_certificate.py -v
To generate figures (requires matplotlib; produces three allowed extra SVG files):
    python3 publication/figures/generate_paper_a_figures.py

Do not interpret these checks as mathematical certification or complete reproduction of every historical
C18/C72 scientific campaign. Full third-party comparison is still not performed; the exact source refs and
frozen historical evidence can be accessed through the protected QTR repository and machine-readable manifest.

C90 remains a separate quality-blind external execution campaign and is not a result in Paper A.

The original source research is public. This bundle does not create any additional copyright license.
